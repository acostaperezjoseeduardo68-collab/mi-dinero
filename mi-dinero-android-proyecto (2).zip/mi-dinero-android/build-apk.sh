#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: Define ANDROID_HOME or ANDROID_SDK_ROOT first."
  exit 1
fi

SDK="${ANDROID_HOME:-$ANDROID_SDK_ROOT}"
export PATH="$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$PATH"

echo "Installing required Android SDK packages..."
yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-37" "build-tools;36.0.0"

echo "Building Mi Dinero APK..."
gradle --no-daemon assembleDebug

echo "APK: app/build/outputs/apk/debug/app-debug.apk"
