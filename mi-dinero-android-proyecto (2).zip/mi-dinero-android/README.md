# Mi Dinero — Proyecto APK Android

Esta carpeta contiene una aplicación Android que envuelve la versión web de Mi Dinero en un WebView.

## Generar la APK

1. Instala Android Studio en Windows/Mac/Linux.
2. Abre esta carpeta como proyecto.
3. Deja que Android Studio sincronice Gradle y descargue el Android SDK requerido.
4. Selecciona **Build > Build APK(s)**.
5. La APK de depuración quedará normalmente en `app/build/outputs/apk/debug/app-debug.apk`.
6. Pásala al S25 e instálala. Puede que Android pida habilitar la instalación de apps desde esa fuente.

## Características del envoltorio Android

- Nombre: Mi Dinero
- ID: `com.midinero.app`
- Android mínimo: 8.0 (API 26)
- Target SDK: 37
- Acceso a Internet para consultar la tasa BCV.
- Selector de archivos habilitado para la foto de perfil.
- Almacenamiento DOM/localStorage disponible para conservar los datos de la app.
